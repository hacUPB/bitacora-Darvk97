#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup() {
	ofBackground(0);
	ofSetFrameRate(60);
	elapsedTime = 0.0f;

	particleCount = 0;
	for (int i = 0; i < MAX_PARTICLES; ++i)
		particles[i] = nullptr;

	trail = new LinkedListTrail();
	colorStack = new ColorStack();
	eventQueue = new EventQueue();

	currentColor = ofColor::fromHsb(ofRandom(0, 255), 200, 255);

	spawnMode = 0; // instant by default

	colorStack->push(currentColor);
}

//--------------------------------------------------------------
void ofApp::update() {
	float dt = ofGetLastFrameTime();
	elapsedTime += dt;

	for (int i = 0; i < MAX_PARTICLES; ++i) {
		if (particles[i]) {
			particles[i]->update(dt);
			if (!particles[i]->alive) {
				delete particles[i];
				particles[i] = nullptr;
				--particleCount;
			}
		}
	}

	SpawnEvent * ev = nullptr;
	while ((ev = eventQueue->popReady(elapsedTime)) != nullptr) {
		spawnParticleAt(ev->pos, ev->color);
		delete ev;
	}

	ofVec2f leaderPos(ofGetWidth() * 0.5, ofGetHeight() * 0.5);
	bool foundLeader = false;
	for (int i = 0; i < MAX_PARTICLES; ++i) {
		if (particles[i]) {
			leaderPos = particles[i]->pos;
			foundLeader = true;
			break;
		}
	}
	if (foundLeader) {
		trail->pushFront(leaderPos);
		trail->popBackKeepMax(80);
	} else {
		trail->popBackKeepMax(0);
	}
}

//--------------------------------------------------------------
void ofApp::draw() {
	ofSetColor(0, 0, 0, 30);
	ofDrawRectangle(0, 0, ofGetWidth(), ofGetHeight());

	for (int i = 0; i < MAX_PARTICLES; ++i) {
		if (particles[i]) particles[i]->draw();
	}

	trail->draw();

	ofSetColor(255);
	string info;
	info += "a: spawn random | mouse click: spawn at mouse\n";
	info += "s: toggle spawn mode (0=instant, 1=queued) - mode: " + ofToString(spawnMode) + "\n";
	info += "d: push current color (change current color randomly)\n";
	info += "u: undo color (pop color stack)\n";
	info += "space: clear all\n";
	info += "Particles: " + ofToString(particleCount) + "/" + ofToString(MAX_PARTICLES) + "\n";
	info += "Color stack size: " + ofToString(colorStack->size) + "\n";
	ofDrawBitmapStringHighlight(info, 10, 20);
}

//--------------------------------------------------------------
void ofApp::spawnParticleAt(const ofVec2f & p, const ofColor & c) {
	for (int i = 0; i < MAX_PARTICLES; ++i) {
		if (!particles[i]) {
			ofVec2f vel(ofRandom(-60, 60), ofRandom(-60, 60));
			float r = ofRandom(2.0f, 6.0f);
			float life = ofRandom(1.5f, 4.0f);
			particles[i] = new Particle(p, vel, c, r, life);
			++particleCount;
			return;
		}
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
	if (key == 'a') {
		ofVec2f p(ofRandomWidth(), ofRandomHeight());
		if (spawnMode == 0) {
			spawnParticleAt(p, currentColor);
		} else {
			float when = elapsedTime + ofRandom(0.6f, 1.6f);
			SpawnEvent * ev = new SpawnEvent(p, when, currentColor);
			eventQueue->push(ev);
		}
	} else if (key == 's') {
		spawnMode = 1 - spawnMode;
	} else if (key == 'd') {
		colorStack->push(currentColor);
		currentColor = ofColor::fromHsb(ofRandom(0, 255), 200, 255);
	} else if (key == 'u') {
		ofColor prev;
		if (colorStack->pop(prev)) {
			currentColor = prev;
		}
	} else if (key == ' ') {
		clearAll();
	}
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	ofVec2f p(x, y);
	if (spawnMode == 0) {
		spawnParticleAt(p, currentColor);
	} else {
		float when = elapsedTime + ofRandom(0.3f, 1.0f);
		SpawnEvent * ev = new SpawnEvent(p, when, currentColor);
		eventQueue->push(ev);
	}
}

//--------------------------------------------------------------
void ofApp::clearAll() {
	for (int i = 0; i < MAX_PARTICLES; ++i) {
		if (particles[i]) {
			delete particles[i];
			particles[i] = nullptr;
		}
	}
	particleCount = 0;

	if (trail) {
		trail->clear();
	}
	if (colorStack) {
		colorStack->clear();
	}
	if (eventQueue) {
		eventQueue->clear();
	}

	// en ofApp.h
	ofApp();

	ofApp::~ofApp();
	{
		clearAll();
		if (trail) {
			delete trail;
			trail = nullptr;
		}
		if (colorStack) {
			delete colorStack;
			colorStack = nullptr;
		}
		if (eventQueue) {
			delete eventQueue;
			eventQueue = nullptr;
		}
	}
}
