#pragma once

#include "ofMain.h"

class Particle {
public:
	ofVec2f pos;
	ofVec2f vel;
	ofColor color;
	float radius;
	float life;
	bool alive;

	Particle(const ofVec2f & p, const ofVec2f & v, const ofColor & c, float r, float lifeSec)
		: pos(p)
		, vel(v)
		, color(c)
		, radius(r)
		, life(lifeSec)
		, alive(true) { }

	void update(float dt) {
		if (!alive) return;
		pos += vel * dt;
		life -= dt;
		if (life <= 0) alive = false;
		vel *= 0.995f;
	}

	void draw() {
		if (!alive) return;
		ofSetColor(color, ofMap(life, 0, 3.0f, 0, 255));
		ofDrawCircle(pos, radius);
	}
};

class TrailNode {
public:
	ofVec2f pos;
	TrailNode * next;
	TrailNode(const ofVec2f & p)
		: pos(p)
		, next(nullptr) { }
	~TrailNode() { }
};

class LinkedListTrail {
public:
	TrailNode * head;
	int size;
	LinkedListTrail()
		: head(nullptr)
		, size(0) { }
	~LinkedListTrail() {
		clear();
	}

	void pushFront(const ofVec2f & p) {
		TrailNode * n = new TrailNode(p);
		n->next = head;
		head = n;
		++size;
	}

	void popBackKeepMax(int maxLen) {
		if (!head) return;
		while (size > maxLen) {
			if (head->next == nullptr) {
				delete head;
				head = nullptr;
				size = 0;
				return;
			}
			TrailNode * cur = head;
			while (cur->next && cur->next->next)
				cur = cur->next;
			delete cur->next;
			cur->next = nullptr;
			--size;
		}
	}

	void clear() {
		TrailNode * cur = head;
		while (cur) {
			TrailNode * nxt = cur->next;
			delete cur;
			cur = nxt;
		}
		head = nullptr;
		size = 0;
	}

	void draw() {
		TrailNode * cur = head;
		float alpha = 255;
		float step = (size > 0) ? 255.0f / size : 0;
		while (cur) {
			ofSetColor(255, 255, 255, (int)alpha);
			ofDrawCircle(cur->pos, 2.0f);
			alpha -= step;
			cur = cur->next;
		}
	}
};

class ColorStack {
public:
	struct Node {
		ofColor value;
		Node * next;
		Node(const ofColor & c)
			: value(c)
			, next(nullptr) { }
	};

	Node * topNode;
	int size;
	ColorStack()
		: topNode(nullptr)
		, size(0) { }
	~ColorStack() { clear(); }

	void push(const ofColor & c) {
		Node * n = new Node(c);
		n->next = topNode;
		topNode = n;
		++size;
	}
	bool pop(ofColor & out) {
		if (!topNode) return false;
		Node * n = topNode;
		out = n->value;
		topNode = n->next;
		delete n;
		--size;
		return true;
	}
	void clear() {
		while (topNode) {
			Node * nxt = topNode->next;
			delete topNode;
			topNode = nxt;
		}
		size = 0;
	}
};

class SpawnEvent {
public:
	ofVec2f pos;
	float when;
	ofColor color;
	SpawnEvent(const ofVec2f & p, float w, const ofColor & c)
		: pos(p)
		, when(w)
		, color(c) { }
};

class EventQueue {
public:
	struct Node {
		SpawnEvent * ev;
		Node * next;
		Node(SpawnEvent * e)
			: ev(e)
			, next(nullptr) { }
		~Node() {
			if (ev) delete ev;
		}
	};
	Node * head;
	Node * tail;
	EventQueue()
		: head(nullptr)
		, tail(nullptr) { }
	~EventQueue() { clear(); }

	void push(SpawnEvent * e) {
		Node * n = new Node(e);
		if (!tail) {
			head = tail = n;
		} else {
			tail->next = n;
			tail = n;
		}
	}

	SpawnEvent * popReady(float currentTime) {
		if (!head) return nullptr;
		if (head->ev->when <= currentTime) {
			Node * n = head;
			SpawnEvent * e = head->ev;
			head = head->next;
			if (!head) tail = nullptr;
			n->ev = nullptr;
			delete n;
			return e;
		}
		return nullptr;
	}

	void clear() {
		Node * cur = head;
		while (cur) {
			Node * nxt = cur->next;
			delete cur; 
			cur = nxt;
		}
		head = tail = nullptr;
	}
};


class ofApp : public ofBaseApp {
public:
	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void mousePressed(int x, int y, int button);

	void spawnParticleAt(const ofVec2f & p, const ofColor & c);
	void clearAll();

	static const int MAX_PARTICLES = 300;
	Particle * particles[MAX_PARTICLES]; 
	int particleCount;
	LinkedListTrail * trail; 
	ColorStack * colorStack;
	EventQueue * eventQueue;
	int spawnMode;
	float elapsedTime;
	ofColor currentColor;
};
